from django.apps import AppConfig


class ExamappConfig(AppConfig):
    name = 'examapp'
